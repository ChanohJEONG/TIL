package com.ggoreb.basic.model;

import lombok.Data;

@Data
public class JsonData {
	private int age;
	private String name;
}
