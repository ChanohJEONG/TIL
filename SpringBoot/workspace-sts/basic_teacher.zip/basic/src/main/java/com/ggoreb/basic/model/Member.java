package com.ggoreb.basic.model;

import lombok.Data;

@Data
public class Member {
	private String name;
	private String userId;
	private String userPassword;
}
