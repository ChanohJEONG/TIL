package com.ggoreb.basic.model;

import lombok.Data;

@Data
public class Demo {
	private long seq;
	private String user;
}